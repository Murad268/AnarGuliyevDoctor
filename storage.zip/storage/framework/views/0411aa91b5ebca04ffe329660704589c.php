<?php echo $__env->make('partials._title', ['code' => 'home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <!--Start rev slider wrapper-->
    <section class="rev_slider_wrapper">
        <div id="slider1" class="rev_slider" data-version="5.0">
            <ul>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-transition="fade">
                        <img src="<?php echo e($slide->getImage($slide->banner)); ?>" alt="<?php echo e($slide->title); ?>" width="1920" height="600" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1">

                        <div class="tp-caption tp-resizeme"
                             data-x="center" data-hoffset="0"
                             data-y="center" data-voffset="-115"
                             data-transform_idle="o:1;"
                             data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;"
                             data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                             data-mask_in="x:[100%];y:0;s:inherit;e:inherit;"
                             data-splitin="none"
                             data-splitout="none"
                             data-responsive_offset="on"
                             data-start="700">
                            <div class="slide-content-box mar-lft">
                                <h1><?php echo e($slide->title); ?></h1>
                            </div>
                        </div>

                        <div class="tp-caption tp-resizeme"
                             data-x="center" data-hoffset="0"
                             data-y="center" data-voffset="10"
                             data-transform_idle="o:1;"
                             data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;"
                             data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                             data-mask_in="x:[100%];y:0;s:inherit;e:inherit;"
                             data-splitin="none"
                             data-splitout="none"
                             data-responsive_offset="on"
                             data-start="1500">
                            <div class="slide-content-box mar-lft">
                                <p><?php echo e($slide->text); ?></p>
                            </div>
                        </div>

                        <div class="tp-caption tp-resizeme"
                             data-x="center" data-hoffset="0"
                             data-y="center" data-voffset="100"
                             data-transform_idle="o:1;"
                             data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                             data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                             data-splitin="none"
                             data-splitout="none"
                             data-responsive_offset="on"
                             data-start="2200">
                            <div class="slide-content-box mar-lft">
                                <div class="button">
                                    <a class="" href="<?php echo e(route('client.contactUs')); ?>"><?php echo e(__('breadcrumb.contact')); ?></a>
                                    <a class="btn-style-two" href="<?php echo e(route('client.services')); ?>"><?php echo e(__('breadcrumb.services')); ?></a>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </section>

    <!--End rev slider wrapper-->

    <!--Start welcome area-->
    <section class="welcome-area">
        <div class="container">
            <div class="title text-center wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="0.5s" data-wow-offset="0">
                <h1><?php echo e(__('site.home_page_slider_under_welcome_title')); ?></h1>
                <p><?php echo e(__('site.home_page_slider_under_welcome_subtitle')); ?></p>
            </div>
        </div>
    </section>
    <!--End welcome area-->


    <!--Start services area-->
    <section class="services-area wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="0.5s" data-wow-offset="0">
        <div class="container">
            <div class="sec-title center text-center">
                <h1><span><?php echo e(__('site.services_title')); ?></span></h1>
            </div>
            <div class="row">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Start single item-->
                    <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12">
                        <div class="single-item hvr-float-shadow wow fadeInUp"
                             data-wow-delay="<?php echo e(($index + 1) * 0.2); ?>s" data-wow-duration="0.5s" data-wow-offset="0">
                            <div class="icon-holder">
                                <div class="icon-box">
                                    <div class="icon">
                                        <div class="icon-bg">
                                            <img src="<?php echo e($service->getImage($service->icon)); ?>" alt="<?php echo e($service->title); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="text-holder">
                                <h3><?php echo e($service->title); ?></h3>
                                <p>
                                    <?php echo Str::limit(strip_tags($service->text), 70, '...'); ?>

                                </p>
                                <a href="<?php echo e(route('client.service', $service->slug)); ?>">Read More<i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <!--End single item-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="more-review-button">
                        <a href="<?php echo e(route('client.services')); ?>"><?php echo e(__('site.more_services')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End services area-->

    <!--Start about us area-->
    <section class="about-us-area  wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="0.5s" data-wow-offset="0">
       <?php if (isset($component)) { $__componentOriginalbf57d73fb5d415a75248397fb052c338 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbf57d73fb5d415a75248397fb052c338 = $attributes; } ?>
<?php $component = App\View\Components\AboutComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('about-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AboutComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbf57d73fb5d415a75248397fb052c338)): ?>
<?php $attributes = $__attributesOriginalbf57d73fb5d415a75248397fb052c338; ?>
<?php unset($__attributesOriginalbf57d73fb5d415a75248397fb052c338); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbf57d73fb5d415a75248397fb052c338)): ?>
<?php $component = $__componentOriginalbf57d73fb5d415a75248397fb052c338; ?>
<?php unset($__componentOriginalbf57d73fb5d415a75248397fb052c338); ?>
<?php endif; ?>
    </section>
    <!--End about us area-->

    <!--Start caption box area-->
    <section class="caption-box-area wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="0.5s" data-wow-offset="0">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-holder pull-left">
                        <h1>
                           <?php echo __("site.bringing_section_left"); ?>

                        </h1>
                        <p><?php echo __("site.bringing_section_down"); ?></p>
                    </div>
                    <div class="button pull-right">
                        <a href="<?php echo e(route('client.contactUs')); ?>"><?php echo e(__('breadcrumb.contact')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End caption box area-->

    <?php if (isset($component)) { $__componentOriginal69b0059ab78618977137eb53c6af577d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69b0059ab78618977137eb53c6af577d = $attributes; } ?>
<?php $component = App\View\Components\WhyChooseUsComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('why-choose-us-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\WhyChooseUsComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69b0059ab78618977137eb53c6af577d)): ?>
<?php $attributes = $__attributesOriginal69b0059ab78618977137eb53c6af577d; ?>
<?php unset($__attributesOriginal69b0059ab78618977137eb53c6af577d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69b0059ab78618977137eb53c6af577d)): ?>
<?php $component = $__componentOriginal69b0059ab78618977137eb53c6af577d; ?>
<?php unset($__componentOriginal69b0059ab78618977137eb53c6af577d); ?>
<?php endif; ?>

    <!--Start testimonial area-->
    <section class="testimonial-area wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="0.5s" data-wow-offset="0">
        <div class="container">
            <div class="sec-title center text-center">
                <h1><span><?php echo e(__('site.customer_reviews_title')); ?></span></h1>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="testimonial-carousel">
                        <?php $__currentLoopData = $customerRews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--Start single item-->
                            <div class="single-item text-center">
                                <div class="img-holder">
                                    <img src="<?php echo e($review->image ? $review->getImage($review->image) : asset('assets/default-user.png')); ?>" alt="<?php echo e($review->text); ?>">
                                </div>
                                <div class="text-holder">
                                    <h5><?php echo e($review->service); ?></h5>
                                    <p><?php echo e($review->text); ?></p>
                                </div>
                                <div class="client-info">
                                    <div class="name pull-left">
                                        <h6><?php echo e($review->name); ?></h6>
                                        <p><?php echo e($review->location); ?></p>
                                    </div>
                                    <div class="review-box pull-right">
                                        <ul>
                                            <?php for($i = 0; $i < $review->raiting; $i++): ?>
                                                <li><i class="fa fa-star"></i></li>
                                            <?php endfor; ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!--End single item-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End testimonial area-->

    <!--Start faq content area-->
    <section class="faq-single-area wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="0.5s" data-wow-offset="0">
        <div class="container">
            <div class="sec-title center text-center">
                <h1><span><?php echo e(__('site.faqs_title')); ?></span></h1>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--Start single accordion box-->
                            <div class="accordion accordion-block">
                                <!-- open class for map default [0]   active        -->
                                <div class="accord-btn <?php echo e($key == 0 ? 'active' : ''); ?>"><h4><?php echo e($item->title); ?></h4></div>
                                <!-- open class for map default [0]   collapsed     -->
                                <div class="accord-content <?php echo e($key == 0 ? 'collapsed' : ''); ?>">
                                    <p><?php echo e($item->text); ?></p>
                                </div>
                            </div>
                            <!--End single accordion box-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End faq content area-->

   <?php if (isset($component)) { $__componentOriginalb2629a48c04228b0b7b2d1da6709ceba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2629a48c04228b0b7b2d1da6709ceba = $attributes; } ?>
<?php $component = App\View\Components\PartnersComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partners-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PartnersComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2629a48c04228b0b7b2d1da6709ceba)): ?>
<?php $attributes = $__attributesOriginalb2629a48c04228b0b7b2d1da6709ceba; ?>
<?php unset($__attributesOriginalb2629a48c04228b0b7b2d1da6709ceba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2629a48c04228b0b7b2d1da6709ceba)): ?>
<?php $component = $__componentOriginalb2629a48c04228b0b7b2d1da6709ceba; ?>
<?php unset($__componentOriginalb2629a48c04228b0b7b2d1da6709ceba); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/pages/home.blade.php ENDPATH**/ ?>