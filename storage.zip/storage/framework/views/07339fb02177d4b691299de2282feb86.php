<h1>Mosaic and tribute to Johan Cruyff before kick off at the Clasico</h1>
<p>Hendrik Johannes Cruyff OON was a Dutch professional football player and coach. As a player, he won the Ballon d'Or three times, in 1971, 1973, and 1974</p>
<figure class="media">
    <div data-oembed-url="https://www.youtube.com/watch?v=o6pzgIjuems">
        <div class="embed-responsive embed-responsive-16by9">
            <iframe src="https://www.youtube.com/embed/o6pzgIjuems" class="embed-responsive-item" allowfullscreen></iframe>
        </div>
    </div>
</figure>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/ckeditor/media.blade.php ENDPATH**/ ?>