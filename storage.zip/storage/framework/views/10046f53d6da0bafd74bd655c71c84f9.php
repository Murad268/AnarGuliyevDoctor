<?php echo $__env->make('partials._seo', ['code' => 'services'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Title -->
    <section class="page-title">
        <div class="bg-layer" style="background-image: url(<?php echo e($banners->getImage($banners->contact_banner)); ?>);"></div>
        <div class="auto-container">
            <div class="content-box">
                <h1><?php echo e(__('site.Services')); ?></h1>
                <ul class="bread-crumb clearfix">
                    <li><a href="index-2.html"><?php echo e(__('site.Home')); ?></a></li>
                    <li><?php echo e(__('site.Services')); ?></li>
                </ul>
            </div>
        </div>
    </section>
    <!-- End Page Title -->


    <!-- service-style-two -->
    <section class="service-style-two about-page p_relative">
        <div class="pattern-layer">
            <div class="pattern-1 p_absolute l_20 b_20"
                 style="background-image: url(assets/images/shape/shape-18.png);"></div>
            <div class="pattern-2 p_absolute t_20 r_20"
                 style="background-image: url(assets/images/shape/shape-19.png);"></div>
        </div>
        <div class="auto-container">

            <div class="row clearfix">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one wow fadeInUp animated" data-wow-delay="00ms"
                             data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="<?php echo e($service->getImage($service->image)); ?>" alt="">
                                    <a href="<?php echo e(route("client.service", $service->slug)); ?>"><i class="fas fa-link"></i></a>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="<?php echo e(route("client.service", $service->slug)); ?>"><?php echo e($service->title); ?></a></h3>
                                    <div class="link p_relative d_block"><a href="<?php echo e(route("client.service", $service->slug)); ?>"><?php echo e(__("site.Read More")); ?></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- service-style-two end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/pages/services.blade.php ENDPATH**/ ?>