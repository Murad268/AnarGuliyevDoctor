<!--Start footer area-->
<footer class="footer-area wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s" data-wow-offset="0">
    <div class="container">
        <div class="row">
            <!--Start single footer widget-->
            <div class="col-lg-5 col-md-6 col-sm-6 col-xs-12">
                <div class="single-footer-widget mar-btm">
                    <div class="footer-logo">
                        <a href="<?php echo e(route('client.home')); ?>">
                            <img src="<?php echo e($infos->getImage($infos->logo)); ?>" alt="Awesome Footer Logo">
                        </a>
                    </div>
                    <div class="our-info">
                        <p>  <?php echo Str::limit(strip_tags($firstAboutText), 256, '...'); ?></p>
                        <div class="button">
                            <?php if(!Route::is('client.about')): ?>
                                <a href="<?php echo e(route('client.about')); ?>"> ...<?php echo e(__('site.read_more')); ?></a>
                            <?php else: ?>
                                <a class="" href="#about"><span class="flaticon-arrows-1"></span>Read More</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <!--End single footer widget-->

            <!--Start single footer widget-->
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="single-footer-widget mar-btm">
                    <div class="title">
                        <h3><?php echo e(__('site.usefull_links')); ?></h3>
                    </div>
                    <ul class="usefull-links">
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$menu->is_details_page && $menu->see_on_footer): ?>
                                <li><a href="<?php echo e($menu->link); ?>"><?php echo e($menu->name); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <!--Start single footer widget-->

            <!--Start single footer widget-->
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="single-footer-widget martop">
                    <div class="title">
                        <h3><?php echo e(__('site.contact_details')); ?></h3>
                    </div>
                    <ul class="footer-contact-info">
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-pin map-marker"></span>
                            </div>
                            <div class="text-holder">
                                <h5><span><?php echo e(__('site.address')); ?>:</span> <?php echo strip_tags($infos->address); ?></h5>
                            </div>
                        </li>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-technology"></span>
                            </div>
                            <div class="text-holder">

                                <?php if($infos->phone_first): ?>

                                    <h5><span>Tel:</span> <a href="tel:<?php echo e($infos->phone_first); ?>"><?php echo e($infos->phone_first); ?></a>
                                        <?php if($infos->phone_second): ?>
                                            /
                                            <a href="tel:<?php echo e($infos->phone_second); ?>"><?php echo e($infos->phone_second); ?></a>
                                        <?php endif; ?>
                                    </h5>
                                <?php endif; ?>


                            </div>
                        </li>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-interface"></span>
                            </div>
                            <div class="text-holder">
                                <?php if($infos->email): ?>
                                    <h5><span>Email:</span> <?php echo e($infos->email); ?> </h5>
                                <?php endif; ?>
                            </div>
                        </li>
                        <li>
                            <?php if($infos->mon_satday_opening_time): ?>
                                <div class="icon-holder">
                                    <span class="flaticon-clock"></span>
                                </div>
                                <div class="text-holder">
                                    <h5><span><?php echo e(__('site.off_hrs')); ?>:</span> <?php echo $infos->mon_satday_opening_time; ?></h5>
                                </div>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
            <!--End single footer widget-->
        </div>
    </div>
</footer>
<!--End footer area-->

<!--Start footer bottom area-->
<section class="footer-bottom-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="footer-bottom">
                    <div class="copyright-text pull-left">
                        <?php echo $infos->copyright_text; ?>

                    </div>
                    <div class="footer-social-links pull-right">
                        <ul>
                            <?php if($infos->facebook): ?>
                                <li><a href="<?php echo e($infos->facebook); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                            <?php if($infos->twitter): ?>
                                <li><a href="<?php echo e($infos->twitter); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                            <?php if($infos->linkedin): ?>
                                <li><a href="<?php echo e($infos->linkedin); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                            <?php if($infos->youtube): ?>
                                <li><a href="<?php echo e($infos->youtube); ?>"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                            <?php if($infos->instagram): ?>
                                <li><a href="<?php echo e($infos->instagram); ?>"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                            <?php if($infos->telegram): ?>
                                <li><a href="<?php echo e($infos->telegram); ?>"><i class="fa fa-telegram" aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End footer bottom area-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/components/client-footer-component.blade.php ENDPATH**/ ?>