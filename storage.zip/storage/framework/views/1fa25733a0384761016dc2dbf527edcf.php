<h1>Selected service: <?php echo e($data['service_title']); ?></h1>
<p><strong>Name:</strong> <?php echo e($data['form_name']); ?></p>
<p><strong>Email:</strong> <?php echo e($data['form_email']); ?></p>
<p><strong>Phone:</strong> <?php echo e($data['form_phone']); ?></p>
<p><strong>Address:</strong> <?php echo e($data['address']); ?></p>
<p><strong>Message:</strong> <?php echo e($data['form_message']); ?></p>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/emails/serviceContact.blade.php ENDPATH**/ ?>