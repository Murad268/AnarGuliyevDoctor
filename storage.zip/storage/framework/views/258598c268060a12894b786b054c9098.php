<?php $__env->startSection('content'); ?>
    <!-- Page Title -->
    <section class="page-title">
        <div class="bg-layer" style="background-image: url(assets/images/background/page-title.jpg);"></div>
        <div class="auto-container">
            <div class="content-box">
                <h1><?php echo e(__("site.Contact Us")); ?></h1>
                <ul class="bread-crumb clearfix">
                    <li><a href="index-2.html"><?php echo e(__("site.Home")); ?></a></li>
                    <li><?php echo e(__("site.Contact Us")); ?></li>
                </ul>
            </div>
        </div>
    </section>
    <!-- End Page Title -->


    <!-- contact-info-section -->
    <section class="contact-info-section centred">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                    <div class="single-item">
                        <div class="icon-box"><i class="icon-57"></i></div>
                        <p><?php echo e($infos->address); ?></p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                    <div class="single-item">
                        <div class="icon-box"><i class="icon-58"></i></div>
                        <p>
                            <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="mailto:<?php echo e($email->email); ?>"><?php echo e($email->email); ?></a><br />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                    <div class="single-item">
                        <div class="icon-box"><i class="icon-59"></i></div>
                        <p>
                            <?php $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="tel:<?php echo e(preg_replace('/[^0-9]/', '', $phone->phone)); ?>"><?php echo e($phone->phone); ?></a><br />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- contact-info-section end -->


    <!-- contact-style-two -->
    <section class="contact-style-two p_relative">
        <div class="pattern-layer">
            <div class="pattern-1" style="background-image: url(assets/images/shape/shape-55.png);"></div>
            <div class="pattern-2" style="background-image: url(assets/images/shape/shape-56.png);"></div>
        </div>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-8 col-md-12 col-sm-12 big-column offset-lg-2">
                    <div class="form-inner">
                        <h2><?php echo e(__('site.Leave a Comment')); ?></h2>
                        <form method="POST"
                              id="contact-form">
                            <div class="row clearfix">
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                    <input type="text" name="username" placeholder="<?php echo e(__('site.Your Name')); ?>" required="">
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                    <input type="email" name="email" placeholder="<?php echo e(__("site.Your email")); ?>" required="">
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                    <input type="text" name="phone" required="" placeholder="<?php echo e(__("site.Phone")); ?>">
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                    <input type="text" name="subject" required="" placeholder="<?php echo e(__("site.Subject")); ?>">
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                    <textarea name="message" placeholder="<?php echo e(__("site.Message")); ?>"></textarea>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn mr-0 centred">
                                    <button class="theme-btn btn-one" type="submit" name="submit-form"><?php echo e(__("site.Submit Now")); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- contact-style-two end -->


    <!-- google-map-section -->
    <section class="google-map-section p_relative">
        <div class="map-inner p_relative d_block">
            <div>
                <?php echo $infos->iframe; ?>

            </div>
        </div>
    </section>
    <!-- google-map-section end -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.getElementById('contact-form').addEventListener('submit', function(event) {
            event.preventDefault();

            let formData = new FormData(this);

            fetch("<?php echo e(url('/api/contact-form')); ?>", {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: '<?php echo e(__("site.Submitted")); ?>',
                            text: data.message,
                        });
                        document.getElementById('contact-form').reset();
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: '<?php echo e(__("site.Error")); ?>',
                            text: '<?php echo e(__("site.Submission failed. Please try again.")); ?>',
                        });
                    }
                })
                .catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: '<?php echo e(__("site.Error")); ?>',
                        text: '<?php echo e(__("site.Submission failed. Please try again.")); ?>',
                    });
                });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/pages/contact.blade.php ENDPATH**/ ?>