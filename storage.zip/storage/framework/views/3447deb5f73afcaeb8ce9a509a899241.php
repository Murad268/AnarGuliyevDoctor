<!--Start header area-->
<header class="header-area">
    <div class="container">
        <div class="row header-area-dflex-center">
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-4">
                <div class="logo">
                    <a href="<?php echo e(route('client.home')); ?>">
                        <img src="<?php echo e($infos->getImage($infos->logo)); ?>" alt="<?php echo e($menuRepository->menuByCode('home')->name); ?>">
                    </a>
                </div>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-8">
                <div class="row">
                    <div class="col-md-12">
                        <div class="header-contact-info pull-left">
                            <ul>
                                <li>
                                    <div class="iocn-holder">
                                        <span class="flaticon-technology"></span>
                                    </div>
                                    <div class="text-holder">
                                        <h5>Call us now</h5>
                                        <a href="tel:<?php echo e($infos->phone_first); ?>">
                                            <h5><?php echo e($infos->phone_first); ?></h5>
                                        </a>
                                    </div>
                                </li>
                                <li>
                                    <div class="iocn-holder">
                                        <span class="flaticon-pin"></span>
                                    </div>
                                    <div class="text-holder">
                                        <h5>
                                            <?php echo $infos->address; ?>

                                        </h5>
                                        
                                    </div>
                                </li>
                                <li>
                                    <div class="iocn-holder">
                                        <span class="flaticon-agenda"></span>
                                    </div>
                                    <div class="text-holder">
                                        <h5><?php echo $infos->mon_satday_opening_time; ?></h5>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!--End header area-->

<!--Start mainmenu area-->
<section class="mainmenu-area stricky">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <!--Start mainmenu-->
                <nav class="main-menu">

                    <div class="navbar-header">
                        <div class="search-button search-button-mobile pull-left">
                            <div class="logo">
                                <a href="<?php echo e(route('client.home')); ?>">
                                    <img src="<?php echo e($infos->getImage($infos->logo)); ?>" alt="<?php echo e($menuRepository->menuByCode('home')->name); ?>">
                                </a>
                            </div>
                            
                        </div>
                        <div class="mob-menu-actions">
                            <div class="header-contact-info pull-left">
                                <ul style="padding-top: 10px;">
                                    <li>
                                        <div class="iocn-holder">
                                            <span class="flaticon-technology"></span>
                                        </div>
                                        <div class="text-holder">
                                            <h5>Call us now</h5>
                                            <a href="tel:<?php echo e($infos->phone_first); ?>">
                                                <h5><?php echo e($infos->phone_first); ?></h5>
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="dflex-ac">
                                <!-- <div class="search-button search-button-mobile pull-left">
                                    <div class="toggle-search">
                                        <button><i class="fa fa-search" aria-hidden="true"></i></button>
                                    </div>
                                </div> -->
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="navbar-collapse collapse clearfix">
                        <ul class="navigation clearfix">
                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!$menu->is_details_page): ?>
                                    <li class="<?php echo e($menu->code=="services" or $menu->code == "sitePolicy" ? 'dropdown' : ''); ?> <?php echo e(Route::is('client.'.$menu->code) ? 'current' : ''); ?>"><a href="<?php echo e($menu->link); ?>"><?php echo e($menu->name); ?></a>
                                        <?php if($menu->code == "services"): ?>
                                            <ul>
                                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="">
                                                        <a href="<?php echo e(route('client.service', $service->slug)); ?>"><?php echo e($service->title); ?></a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($allServicesCount>9): ?>
                                                        <li class="">
                                                            <a href="<?php echo e(route('client.services')); ?>">All services</a>
                                                        </li>
                                                    <?php endif; ?>
                                            </ul>
                                        <?php elseif($menu->code == "sitePolicy"): ?>
                                            <ul>
                                                <li><a href="<?php echo e(route('client.privacyPolicy')); ?>">Privacy Policy</a></li>
                                                <li><a href="<?php echo e(route('client.termsAndConditions')); ?>">Terms and Conditions</a></li>
                                                <li><a href="<?php echo e(route('client.refundPolicy')); ?>">Refund Policy</a></li>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                    <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </nav>
                <!--End mainmenu-->
                <div class="search-button search-button-desktop pull-right">
                    <div class="toggle-search">
                        <button><i class="fa fa-search" aria-hidden="true"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Start header-search  area-->
    <section class="header-search">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="search-form pull-right">
                        <form action="<?php echo e(route('search')); ?>" style="margin-bottom: 0;">
                            <div class="search">
                                <input type="search" name="q" value="" placeholder="Search">
                                <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End header-search  area-->
</section>
<!--End mainmenu area-->


<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/components/client-header-component.blade.php ENDPATH**/ ?>