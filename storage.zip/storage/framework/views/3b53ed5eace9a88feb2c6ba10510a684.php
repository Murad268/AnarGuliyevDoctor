<head>
    <meta charset="UTF-8">

    <!-- responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- master stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css?v=4.2')); ?>">
    <!-- Responsive stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css?v=4.2')); ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e($infos->getImage($infos->favicon)); ?>">

</head>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/layouts/includes/head.blade.php ENDPATH**/ ?>