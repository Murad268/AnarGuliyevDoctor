<figure class="table">
    <table>
        <thead>
        <tr>
            <th>Header</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>Row</td>
        </tr>
        </tbody>
    </table>
</figure>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/ckeditor/table.blade.php ENDPATH**/ ?>