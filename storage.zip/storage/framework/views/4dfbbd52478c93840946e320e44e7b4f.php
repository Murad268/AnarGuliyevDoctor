<!-- jQuery plugins -->
<script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/owl.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/validation.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.fancybox.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/appear.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/scrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/isotope.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery-ui.js')); ?>"></script>

<!-- Google Maps and map-helper -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA-CE0deH3Jhj6GN4YvdCFZS7DpbXexzGU"></script>
<script src="<?php echo e(asset('assets/js/gmaps.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/map-helper.js')); ?>"></script>

<!-- Main JavaScript -->
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/layouts/includes/foot.blade.php ENDPATH**/ ?>