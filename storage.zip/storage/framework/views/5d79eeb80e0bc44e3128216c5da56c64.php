<!DOCTYPE html>
<html lang="<?php echo e(Cache::get('app_locale', config('app.locale'))); ?>">

<?php echo $__env->make('layouts.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

<!--Start Preloader -->
<!-- <div class="preloader"></div> -->
<!--End Preloader -->

<?php if (isset($component)) { $__componentOriginalc51af82fb563328e55227eacdc75d53e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc51af82fb563328e55227eacdc75d53e = $attributes; } ?>
<?php $component = App\View\Components\ClientHeaderComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('client-header-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ClientHeaderComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc51af82fb563328e55227eacdc75d53e)): ?>
<?php $attributes = $__attributesOriginalc51af82fb563328e55227eacdc75d53e; ?>
<?php unset($__attributesOriginalc51af82fb563328e55227eacdc75d53e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc51af82fb563328e55227eacdc75d53e)): ?>
<?php $component = $__componentOriginalc51af82fb563328e55227eacdc75d53e; ?>
<?php unset($__componentOriginalc51af82fb563328e55227eacdc75d53e); ?>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>

<?php if (isset($component)) { $__componentOriginal158473df0d7dd9d593228cc45ab51742 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal158473df0d7dd9d593228cc45ab51742 = $attributes; } ?>
<?php $component = App\View\Components\ClientFooterComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('client-footer-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ClientFooterComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal158473df0d7dd9d593228cc45ab51742)): ?>
<?php $attributes = $__attributesOriginal158473df0d7dd9d593228cc45ab51742; ?>
<?php unset($__attributesOriginal158473df0d7dd9d593228cc45ab51742); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal158473df0d7dd9d593228cc45ab51742)): ?>
<?php $component = $__componentOriginal158473df0d7dd9d593228cc45ab51742; ?>
<?php unset($__componentOriginal158473df0d7dd9d593228cc45ab51742); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.includes.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<a href="tel:832-823-3493">
    <div class="call-to-action">
        <i class="fa fa-phone" aria-hidden="true"></i>
    </div>
</a>


</body>

</html>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>