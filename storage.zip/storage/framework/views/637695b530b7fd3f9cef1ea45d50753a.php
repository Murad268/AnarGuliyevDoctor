<?php $__env->startSection('content'); ?>

    <!-- Page Title -->
    <section class="page-title">
        <div class="bg-layer" style="background-image: url(<?php echo e($banners->getImage($banners->contact_banner)); ?>);"></div>
        <div class="auto-container">
            <div class="content-box">
                <h1><?php echo e(__('site.Portfolio')); ?></h1>
                <ul class="bread-crumb clearfix">
                    <li><a href="index-2.html"><?php echo e(__("site.Home")); ?></a></li>
                    <li><?php echo e(__('site.Portfolio')); ?></li>
                </ul>
            </div>
        </div>
    </section>
    <!-- End Page Title -->


    <!-- portfolio-page-section -->
    <section class="portfolio-page-section p_relative">
        <div class="auto-container">
            <div class="sortable-masonry">
                <div class="filters mb_50">
                    <ul class="filter-tabs filter-btns clearfix centred">
                        <li class="active filter" data-role="button" data-filter=".video"><?php echo e(__("Video")); ?></li>
                        <li class="filter" data-role="button" data-filter=".photo"><?php echo e(__("Photo")); ?></li>
                    </ul>
                </div>
                <div class="items-container row clearfix">
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="col-lg-4 col-md-6 col-sm-12 masonry-item small-column  video ">
                            <div class="project-block-one">
                                <div class="inner-box">
                                    <figure class="image-box"><img src="<?php echo e($video->getImage($video->video_image)); ?>" alt="">
                                    </figure>
                                    <div class="view-btn"><a href="<?php echo e($video->video); ?>"
                                                             class="lightbox-image" data-fancybox="gallery"><i class="icon-33"></i></a>
                                    </div>
                                    <div class="text">
                                        <span><?php echo e($video->text); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="col-lg-4 col-md-6 col-sm-12 masonry-item small-column photo">
                                <div class="project-block-one">
                                    <div class="inner-box">
                                        <figure class="image-box"><img src="<?php echo e($gallery->getImage($gallery->image)); ?>" alt="">
                                        </figure>
                                        <div class="view-btn"><a href="<?php echo e($gallery->getImage($gallery->image)); ?>"
                                                                 class="lightbox-image" data-fancybox="gallery"><i class="icon-33"></i></a>
                                        </div>
                                        <div class="text">
                                            <span><?php echo e($gallery->text); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <!-- portfolio-page-section end -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/pages/portfolio.blade.php ENDPATH**/ ?>