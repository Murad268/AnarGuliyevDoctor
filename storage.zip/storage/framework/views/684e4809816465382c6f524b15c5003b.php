<!-- main jQuery -->
<script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
<!-- Wow Script -->
<script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
<!-- bootstrap -->
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- owl carousel -->
<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
<!-- validate -->
<script src="<?php echo e(asset('assets/js/validation.js')); ?>"></script>
<!-- accordion -->
<script src="<?php echo e(asset('assets/js/jquery.prettyPhoto.js')); ?>"></script>

<!-- revolution slider js -->
<script src="<?php echo e(asset('assets/revolution/js/jquery.themepunch.tools.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/jquery.themepunch.revolution.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.actions.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.kenburn.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.layeranimation.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.migration.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.navigation.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.slideanims.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.video.min.js')); ?>"></script>

<!-- thm custom script -->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/layouts/includes/foot.blade.php ENDPATH**/ ?>