<div   class="container">
    <div class="sec-title">
        <h1><span><?php echo e(__('site.about_title')); ?></span></h1>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="img-holder">
                <img src="<?php echo e($aboutData->getImage($aboutData->image)); ?>" alt="Awesome Image">
            </div>
        </div>
        <div class="col-md-4">
            <div class="middle-text-box">
                <div class="single-item top">
                    <h3><?php echo e($aboutData->first_title); ?></h3>
                    <?php if(Route::is('client.home')): ?>
                        <p><?php echo substr(strip_tags($aboutData->second_text), 0, 240); ?><small><a href="<?php echo e(route('client.about')); ?>"> ...<?php echo e(strtolower(__('site.read_more'))); ?></a></small></p>
                    <?php else: ?>
                        <p><?php echo $aboutData->second_text; ?></p>
                    <?php endif; ?>
                </div>
                <div class="single-item">
                    <h3><?php echo e($aboutData->second_title); ?></h3>
                    <?php if(Route::is('client.home')): ?>
                        <p><?php echo substr(strip_tags($aboutData->second_text), 0, 240); ?><small><a href="<?php echo e(route('client.about')); ?>"> ...<?php echo e(strtolower(__('site.read_more'))); ?></a></small></p>
                    <?php else: ?>
                        <p><?php echo $aboutData->second_text; ?></p>
                    <?php endif; ?>
                </div>


            </div>
        </div>
        <div class="col-md-4">
            <div class="right-info-box">
                <?php if($infos->emergency_service_phone): ?>
                    <div class="top">
                        <div class="iocn-holder">
                            <span class="flaticon-technology-1"></span>
                        </div>
                        <div class="text-holder">
                            <h3><?php echo e(__('site.about_aside_title')); ?></h3>
                            <span><?php echo e(__('site.about_aside_subtitle')); ?></span>
                        </div>
                    </div>
                    <div class="middle">
                        <h1><?php echo e($infos->emergency_service_phone); ?></h1>
                        <p><?php echo __('site.emergency_text'); ?></p>
                    </div>
                <?php endif; ?>
                <div class="bottom">
                    <h4><?php echo e(__('site.for_queries')); ?>:</h4>
                    <ul>
                        <?php if($infos->phone_first): ?>
                            <li><span><?php echo e(__('site.tel')); ?>:</span> <a href="tel:<?php echo e($infos->phone_first); ?>"><?php echo e($infos->phone_first); ?></a>
                                <?php if($infos->phone_second): ?>
                                    /
                                    <a href="tel:<?php echo e($infos->phone_second); ?>"><?php echo e($infos->phone_second); ?></a>
                                <?php endif; ?>
                            </li>
                        <?php endif; ?>
                        <?php if($infos->email): ?>
                            <li><span><?php echo e(__('site.email')); ?>:</span> <?php echo e($infos->email); ?> </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/components/about-component.blade.php ENDPATH**/ ?>