<?php echo $__env->make('partials._seo', ['code' => 'blogs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <section class="page-title">
        <div class="bg-layer" style="background-image: url(<?php echo e($banners->getImage($banners->contact_banner)); ?>);"></div>
        <div class="auto-container">
            <div class="content-box">
                <h1><?php echo e(__("site.Blogs")); ?></h1>
                <ul class="bread-crumb clearfix">
                    <li><a href="index-2.html"><?php echo e(__("site.Home")); ?></a></li>
                    <li><?php echo e(__("site.Blogs")); ?></li>
                </ul>
            </div>
        </div>
    </section>
    <!-- End Page Title -->
    <!-- news-section -->
    <section class="news-section blog-grid p_relative">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="row clearfix">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-12 news-block">
                            <div class="news-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                                <div class="inner-box">
                                    <figure class="image-box">
                                        <img src="<?php echo e($blog->getImage($blog->imagefile)); ?>" alt="">
                                        <a href="<?php echo e(route('client.blog', $blog->slug)); ?>"><?php echo e(__("site.Read More")); ?>"><i class="fas fa-link"></i></a>
                                    </figure>
                                    <div class="lower-content">
                                        <div class="inner">
                                            <div class="category"><a href="<?php echo e(route('client.blog', $blog->slug)); ?>"><?php echo e($blog->category->title); ?></a></div>
                                            <h3><a href="<?php echo e(route('client.blog', $blog->slug)); ?>"><?php echo \Illuminate\Support\Str::limit($blog->title, 50, '...'); ?></a></h3>
                                            <ul class="post-info clearfix">
                                                <li><i class="icon-34"></i><?php echo e(\Carbon\Carbon::parse($blog->date)->format('d/m/Y')); ?></li>
                                            </ul>

                                            <div class="link"><a href="<?php echo e(route('client.blog', $blog->slug)); ?>"><?php echo e(__("site.Read More")); ?></a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="pagination-wrapper centred centred">
                <?php if($blogs->hasPages()): ?>
                    <ul class="pagination clearfix">
                        
                        <?php if($blogs->onFirstPage()): ?>
                            <li class="disabled"><span><i class="fas fa-angle-left"></i></span></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($blogs->previousPageUrl()); ?>"><i class="fas fa-angle-left"></i></a></li>
                        <?php endif; ?>

                        
                        <?php $__currentLoopData = $blogs->getUrlRange(1, $blogs->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $blogs->currentPage()): ?>
                                <li><a href="<?php echo e($url); ?>" class="current"><?php echo e($page); ?></a></li>
                            <?php else: ?>
                                <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php if($blogs->hasMorePages()): ?>
                            <li><a href="<?php echo e($blogs->nextPageUrl()); ?>"><i class="fas fa-angle-right"></i></a></li>
                        <?php else: ?>
                            <li class="disabled"><span><i class="fas fa-angle-right"></i></span></li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>

            </div>
        </div>
    </section>
    <!-- news-section end -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/pages/blogs.blade.php ENDPATH**/ ?>