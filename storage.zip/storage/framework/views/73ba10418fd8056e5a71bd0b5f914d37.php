<h1><?php echo e($data['form_subject']); ?></h1>
<p><strong>Name:</strong> <?php echo e($data['form_name']); ?></p>
<p><strong>Email:</strong> <?php echo e($data['form_email']); ?></p>
<p><strong>Phone:</strong> <?php echo e($data['form_phone']); ?></p>
<p><strong>Message:</strong> <?php echo e($data['form_message']); ?></p>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/emails/contact.blade.php ENDPATH**/ ?>