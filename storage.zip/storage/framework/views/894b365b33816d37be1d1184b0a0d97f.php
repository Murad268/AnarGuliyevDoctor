<!--Start choose us area-->
<section class="choose-us-area wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s" data-wow-offset="0">
    <div class="container">
        <div class="sec-title center text-center">
            <h1><span><?php echo e(__('site.why_choose_us')); ?></span></h1>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="choose-carousel">
                    <?php $__currentLoopData = $whyUsElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--Start single item-->
                        <div class="single-item">
                            <div class="inner-content">
                                <div class="icon-holder">
                                      <!-- Icon from DB -->
                                    <img style="width: 60px" src="<?php echo e($element->getImage($element->icon)); ?>">
                                </div>
                                <div class="title-holder">
                                    <h3><?php echo e($element->title); ?></h3>
                                    <p><?php echo e($element->subtitle); ?></p>
                                </div>
                            </div>
                            <div class="overlay-content">
                                <div class="box">
                                    <div class="content">
                                        <h3><?php echo e($element->title); ?></h3>
                                        <b><?php echo e($element->subtitle); ?></b>
                                        <span class="border"></span>
                                        <p><?php echo e($element->text); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End single item-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End choose us area-->
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/components/why-choose-us-component.blade.php ENDPATH**/ ?>