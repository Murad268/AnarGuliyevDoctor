<?php if(isset($is_details)): ?>
    <title><?php echo e($code); ?></title>
<?php else: ?>
    <title><?php echo e($menuRepository->menuByCode($code)->name); ?> || Leader Appliance</title>
<?php endif; ?>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/partials/_title.blade.php ENDPATH**/ ?>