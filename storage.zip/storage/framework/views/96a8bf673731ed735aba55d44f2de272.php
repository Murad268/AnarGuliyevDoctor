
            <p class="text-center">Powered by <a class="link-default" href="https://nova.laravel.com">Laravel Nova</a> · v<?php echo $version; ?></p>
            <p class="text-center">&copy; <?php echo $year; ?> Laravel LLC &middot; by Taylor Otwell and David Hemphill.</p>
        <?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\storage\framework\views/99a867f530496edb88dca54ef7748a2b.blade.php ENDPATH**/ ?>