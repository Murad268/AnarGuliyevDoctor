<?php if(isset($code)): ?>
    <title><?php echo e($menuRepository->menuByCode($code)->seo_title); ?></title>
    <meta name="keywords" content="<?php echo e($menuRepository->menuByCode($code)->meta_keywords); ?>">
    <meta name="description" content="<?php echo e($menuRepository->menuByCode($code)->meta_description); ?>">
<?php elseif($blog ?? false): ?>
    <title><?php echo e($blog->title); ?></title>
    <meta name="keywords" content="<?php echo e($blog->meta_keywords); ?>">
    <meta name="description" content="<?php echo e($blog->meta_description); ?>">
<?php elseif($service ?? false): ?>
    <title><?php echo e($blog->title); ?></title>
    <meta name="keywords" content="<?php echo e($blog->meta_keywords); ?>">
    <meta name="description" content="<?php echo e($blog->meta_description); ?>">
<?php else: ?>

<?php endif; ?>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/partials/_seo.blade.php ENDPATH**/ ?>