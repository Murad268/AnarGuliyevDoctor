<!--Start Brand area-->
<section class="brand-area wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s" data-wow-offset="0">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="brand">
                    <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--Start single item-->
                        <div class="single-item">
                            <a href="#"><img src="<?php echo e($partner->getImage($partner->image)); ?>" alt="<?php echo e($partner->title); ?>"></a>
                        </div>
                        <!--End single item-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End Brand area-->
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/components/partners-component.blade.php ENDPATH**/ ?>