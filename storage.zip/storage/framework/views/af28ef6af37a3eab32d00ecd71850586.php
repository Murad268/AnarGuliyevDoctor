<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._breadcrumb', ['first_crumb' => ['title'=>__('breadcrumb.contact'), 'link' => route('client.contactUs')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials._title', ['code' => 'contactUs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Start contact area-->
<section class="contact-area">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="contact-info">
                    <div class="title">
                        <h2><?php echo e(__('site.quick_contact')); ?></h2>
                    </div>
                    <div class=" ">
                        <ul class="contact-info-list row">
                            <li class="col-sm-6 col-md-12">
                                <div class="icon-holder">
                                    <span class="flaticon-pin"></span>
                                </div>
                                <div class="text-holder">
                                    <h5><?php echo strip_tags( $infos->address ); ?></h5>
                                </div>
                            </li>
                            <li class="col-sm-6 col-md-12">
                                <div class="icon-holder">
                                    <span class="flaticon-technology"></span>
                                </div>
                                <div class="text-holder">
                                    <h5><span><?php echo e(__('site.call_us')); ?></span><br>
                                        <?php if($infos->phone_first): ?>
                                          <a href="tel:<?php echo e($infos->phone_first); ?>"><?php echo e($infos->phone_first); ?></a>
                                                <?php if($infos->phone_second): ?>
                                                    /
                                                    <a href="tel:<?php echo e($infos->phone_second); ?>"><?php echo e($infos->phone_second); ?></a>
                                                <?php endif; ?>
                                        <?php endif; ?>
                                    </h5>
                                </div>
                            </li>
                            <li class="col-sm-6 col-md-12">
                                <div class="icon-holder">
                                    <span class="flaticon-interface"></span>
                                </div>
                                <div class="text-holder">
                                    <h5><span><?php echo e(__('site.mail_us')); ?></span><br>
                                    <?php if($infos->email): ?>
                                        <a href="<?php echo e($infos->email); ?>"><?php echo e($infos->email); ?></a>
                                    <?php endif; ?>
                                    </h5>
                                </div>
                            </li>
                            <li class="col-sm-6 col-md-12">
                                <?php if($infos->mon_satday_opening_time): ?>
                                    <div class="icon-holder">
                                        <span class="flaticon-clock"></span>
                                    </div>
                                    <div class="text-holder">
                                        <h5><span><?php echo e(__('site.opening_time')); ?></span><br><?php echo $infos->mon_satday_opening_time; ?></h5>
                                    </div>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="contact-form">
                    <div class="title">
                        <h2><?php echo e(__('form.send_message_us')); ?></h2>
                    </div>
                    <form id="contact-form" name="contact_form" class="default-form" action="<?php echo e(route('contact.contact')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="col-md-6">
                                <input type="text" name="form_name" value="" placeholder="<?php echo e(__('form.your_name')); ?>*" required="">
                            </div>
                            <div class="col-md-6">
                                <input type="email" name="form_email" value="" placeholder="<?php echo e(__('form.your_email')); ?>*" required="">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" name="form_phone" value="" placeholder="<?php echo e(__('form.phone')); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="form_subject" value="" placeholder="<?php echo e(__('form.subject')); ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <textarea name="form_message" placeholder="<?php echo e(__('form.your_message')); ?>.." required=""></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">
                                <button class="thm-btn bg-1" type="submit" data-loading-text="<?php echo e(__('form.please_wait')); ?>..."><?php echo e(__('form.send_message')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End contact area-->
    <div id="loading-overlay" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255, 255, 255, 0.8); z-index: 9999; text-align: center;">
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
            <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>

<!--Start Google map area-->
<section class="google-map-area">
    <?php echo $infos->map; ?>

</section>
<!--End Google map area-->

<?php $__env->stopSection(); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('#contact-form').on('submit', function (e) {
                e.preventDefault(); // Prevent default form submission

                // Show the loading overlay, disable the submit button, and disable scrolling
                $('#loading-overlay').show();
                $('body').css('overflow', 'hidden'); // Disable scrolling
                $('button[type="submit"]').prop('disabled', true);

                let formData = $(this).serialize(); // Serialize form data

                $.ajax({
                    url: "<?php echo e(route('contact.contact')); ?>", // The form action URL
                    type: "POST", // HTTP method
                    data: formData,
                    success: function (response) {
                        $('#loading-overlay').hide(); // Hide the loading overlay
                        $('body').css('overflow', ''); // Restore scrolling
                        $('button[type="submit"]').prop('disabled', false); // Re-enable the button

                        if (response.success) {
                            // SweetAlert success
                            Swal.fire({
                                title: 'Success!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });

                            // Optionally clear the form
                            $('#contact-form')[0].reset();
                        }
                    },
                    error: function (xhr) {
                        $('#loading-overlay').hide(); // Hide the loading overlay
                        $('body').css('overflow', ''); // Restore scrolling
                        $('button[type="submit"]').prop('disabled', false); // Re-enable the button

                        let errors = xhr.responseJSON.errors;

                        // SweetAlert error
                        Swal.fire({
                            title: 'Error!',
                            text: 'Please correct the errors and try again.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });

                        // Optionally display the validation errors in console
                        console.error(errors);
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/pages/contactUs.blade.php ENDPATH**/ ?>