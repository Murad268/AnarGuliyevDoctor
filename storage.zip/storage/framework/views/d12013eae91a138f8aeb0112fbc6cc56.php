<?php $__env->startSection('content'); ?>


    <!-- Page Title -->
    <section class="page-title">
        <div class="bg-layer" style="background-image: url(<?php echo e($banners->getImage($banners->about_banner)); ?>);"></div>
        <div class="auto-container">
            <div class="content-box">
                <h1><?php echo e(__("site.About Us")); ?></h1>
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo e(route('client.home')); ?>"><?php echo e(__('site.Home')); ?></a></li>
                    <li><?php echo e(__("site.About Us")); ?></li>
                </ul>
            </div>
        </div>
    </section>
    <!-- End Page Title -->


    <!-- about-section -->
    <section class="about-section">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                    <div class="image_block_one">
                        <div class="image-box mr_30 pr_130 pb_100">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-1.png"></div>
                            <figure class="image"><img src="<?php echo e($who->getImage($who->image)); ?>" alt=""></figure>
                            <div class="text p_absolute r_0 b_0">
                                <h2><?php echo e($who->image_subbox_text_top); ?></h2>
                                <h4><?php echo e($who->image_subbox_text_bottom); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                    <div class="content_block_one">
                        <div class="content-box ml_30">
                            <div class="sec-title left p_relative d_block mb_25">
                                <span class="sub-title"><?php echo e(__('site.Who We Are?')); ?></span>
                                <h2><?php echo e($who->title); ?></h2>
                            </div>
                            <div class="text p_relative d_block">
                                <p><?php echo e($who->text); ?></p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about-section end -->


    <!-- service-style-two -->
    <section class="service-style-two about-page p_relative">
        <div class="pattern-layer">
            <div class="pattern-1 p_absolute l_20 b_20"
                 style="background-image: url(assets/images/shape/shape-18.png);"></div>
            <div class="pattern-2 p_absolute t_20 r_20"
                 style="background-image: url(assets/images/shape/shape-19.png);"></div>
        </div>
        <div class="auto-container">
            <div class="sec-title centred mb_50">
                <span class="sub-title"><?php echo e(__("site.My Services")); ?></span>
                <h2><?php echo e(__("site.My Services_subtitle")); ?></h2>
            </div>
            <div class="row clearfix">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one wow fadeInUp animated" data-wow-delay="00ms"
                             data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="<?php echo e($service->getImage($service->image)); ?>" alt="">
                                    <a href="surgical-procedures.html"><i class="fas fa-link"></i></a>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="surgical-procedures.html"><?php echo e($service->title); ?></a></h3>
                                    <div class="link p_relative d_block"><a href="surgical-procedures.html"><?php echo e(__("site.Read More")); ?></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- service-style-two end -->



    <!-- chooseus-style-two -->
    <section style="height: 600px;" class="chooseus-style-two about-page p_relative">
        <div class="shape-3 p_absolute t_0 r_0">
        </div>

        <div class="video-column" style="background-image: url(<?php echo e($aboutWho->getImage($aboutWho->video_thumbnail)); ?>);">
            <div class="video-inner">
                <div class="video-btn">
                    <a href="<?php echo e($aboutWho->video); ?>" class="lightbox-image"
                       data-caption=""><i class="fas fa-play"></i></a>
                </div>
            </div>
        </div>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                    <div class="content_block_five">
                        <div class="content-box mr_70">
                            <div class="sec-title light mb_35">
                                <span class="sub-title"><?php echo e(__("site.Why Choose")); ?></span>
                                <h2 class="mb_25"><?php echo e($aboutWho->title); ?></h2>
                                <p class="pt_2"><?php echo e($aboutWho->text); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- chooseus-style-two end -->







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/pages/about.blade.php ENDPATH**/ ?>