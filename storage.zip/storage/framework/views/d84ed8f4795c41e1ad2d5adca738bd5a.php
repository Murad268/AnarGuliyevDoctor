<?php echo $__env->make('partials._seo', ['blog' => $blog], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>




    <!-- Page Title -->
    <section class="page-title">
        <div class="bg-layer" style="background-image: url(<?php echo e($banners->getImage($banners->blogs_banner)); ?>);"></div>
        <div class="auto-container">
            <div class="content-box">
                <h1>Blog Details</h1>
                <ul class="bread-crumb clearfix">
                    <li><a href="index-2.html">Home</a></li>
                    <li>Blog Details</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- End Page Title -->


    <!-- sidebar-page-container -->
    <section class="sidebar-page-container p_relative">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-8 col-md-12 col-sm-12 content-side">
                    <div class="blog-details-content">
                        <div class="news-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="<?php echo e($blog->getImage($blog->imagefile)); ?>" alt="">
                                </figure>
                                <div class="lower-content">
                                    <div class="inner">
                                        <div class="category"><a href="blog-details.html"><?php echo e($blog->category->title); ?></a></div>
                                        <h3><?php echo e($blog->title); ?></h3>
                                        <ul class="post-info clearfix">
                                            <li><i class="icon-34"></i><?php echo e(\Carbon\Carbon::parse($blog->date)->format('d/m/Y')); ?></li>
                                            </li>
                                        </ul>
                                        <div>
                                            <?php echo $blog->text; ?>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="post-tags">
                            <?php
                                // Tags stringini müəyyən edin (məsələn, databazadan gələn data)


                                // Stringi vergülə görə parçala
                                $tags = explode(',', $blog->tags);
                            ?>

                            <ul class="tags-list clearfix">
                                <li>
                                    <h5><?php echo e(__('site.tags')); ?>:</h5>
                                </li>
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="blog-details.html"><?php echo e($tag); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                        </div>


                    </div>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 sidebar-side">
                    <div class="blog-sidebar ml_40">
                        <div class="sidebar-widget search-widget">
                            <div class="widget-title">
                                <h3><?php echo e(__('site.Search')); ?></h3>
                            </div>
                            <div class="search-form">
                                <form action="<?php echo e(route('client.blogs')); ?>" method="get">
                                    <div class="form-group">
                                        <input type="search" name="search" placeholder="<?php echo e(__('site.Search')); ?>" required="">
                                        <button type="submit"><i class="icon-50"></i></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="sidebar-widget category-widget">
                            <div class="widget-title">
                                <h3><?php echo e(__('site.Categories')); ?></h3>
                            </div>
                            <div class="widget-content">
                                <ul class="category-list clearfix">
                                    <li><a href="<?php echo e(route("client.blogs")); ?>"><?php echo e(__('site.All Categories')); ?></a></li>
                                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('client.blogs')); ?>?category=<?php echo e($cat->slug); ?>"><?php echo e($cat->title); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="sidebar-widget post-widget">
                            <div class="widget-title">
                                <h3><?php echo e(__("site.Recent Posts")); ?></h3>
                            </div>
                            <div class="post-inner">
                                <?php $__currentLoopData = $recentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="post">
                                        <figure class="post-thumb"><a href="<?php echo e(route('client.blog', $rBlog->slug)); ?>"><img
                                                    src="<?php echo e($rBlog->getImage($rBlog->imagefile)); ?>" alt=""></a></figure>
                                        <h4><a href="b<?php echo e($rBlog->getImage($rBlog->imagefile)); ?>"><?php echo e($rBlog->title); ?></a></h4>
                                        <span class="post-date"><i class="icon-34"></i><?php echo e(\Carbon\Carbon::parse($blog->date)->format('d/m/Y')); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- sidebar-page-container end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/pages/blog.blade.php ENDPATH**/ ?>