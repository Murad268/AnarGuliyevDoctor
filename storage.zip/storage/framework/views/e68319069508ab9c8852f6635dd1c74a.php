



</div>
<!-- main header -->
<header class="main-header">
    <!-- header-top -->
    <div class="header-top">
        <div class="auto-container">
            <div class="top-inner">
                <div class="left-column">
                    <ul class="info clearfix">
                        <li><i class="icon-1"></i> <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></li>
                        <li><i class="icon-3"></i><a href="tel:<?php echo e(preg_replace('/[^0-9]/', '', $phone)); ?>"><?php echo e($phone); ?></a></li>
                    </ul>
                </div>
                <div class="right-column">
                    <div class="schedule"><i class="icon-4"></i><?php echo e($infos->work_hours_weekday); ?></div>
                    <ul class="social-links clearfix">
                        <?php if(!empty($infos->facebook)): ?>
                            <li><a href="<?php echo e($infos->facebook); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                        <?php endif; ?>
                        <?php if(!empty($infos->instagram)): ?>
                            <li><a href="<?php echo e($infos->instagram); ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        <?php endif; ?>
                        <?php if(!empty($infos->tiktok)): ?>
                            <li>
                                <a href="<?php echo e($infos->tiktok); ?>" target="_blank">
                                    <svg width="24" height="24" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" fill="currentColor">
                                        <path d="M33.25 4H30.9a1.6 1.6 0 0 0-1.6 1.6v21.68a4.88 4.88 0 1 1-3.62-4.74v-4.3a9.18 9.18 0 1 0 7.1 8.91V10.83a14.48 14.48 0 0 0 5.48 1.09h1.47a1.6 1.6 0 0 0 1.6-1.6V7.65A1.6 1.6 0 0 0 40.23 6h-.36a9.16 9.16 0 0 1-6.62-2.9V4z"/>
                                    </svg>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(!empty($infos->twitter)): ?>
                            <li><a href="<?php echo e($infos->twitter); ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
                        <?php endif; ?>
                        <?php if(!empty($infos->linkedin)): ?>
                            <li><a href="<?php echo e($infos->linkedin); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                        <?php endif; ?>

                        <?php if(!empty($infos->youtube)): ?>
                            <li><a href="<?php echo e($infos->youtube); ?>" target="_blank"><i class="fab fa-youtube"></i></a></li>
                        <?php endif; ?>
                    </ul>




                </div>
            </div>
        </div>
    </div>
    <!-- header-lower -->
    <div class="header-lower">
        <div class="auto-container">
            <div class="outer-box">
                <div class="logo-box">
                    <figure class="logo"><a href="<?php echo e(route("client.home")); ?>"><img src="<?php echo e($infos->getImage($infos->logo)); ?>" alt=""></a></figure>
                </div>
                <div class="menu-area clearfix">
                    <!--Mobile Navigation Toggler-->
                    <div class="mobile-nav-toggler">
                        <i class="icon-bar"></i>
                        <i class="icon-bar"></i>
                        <i class="icon-bar"></i>
                    </div>
                    <nav class="main-menu navbar-expand-md navbar-light">
                        <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                            <ul class="navigation clearfix">
                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!$menu->is_details_page): ?>
                                        <li class="<?php echo e(Route::is('client.'.$menu->code) ? 'current' : ''); ?>">
                                            <a href="<?php echo e($menu->link); ?>"><?php echo e($menu->name); ?></a>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </nav>
                </div>
                <div class="nav-right">

                    <div style="display: flex; gap: 10px; margin-right: 30px">
                        <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div style="display: flex; align-items: center;">
                                <a href="<?php echo e(url('language')); ?>/<?php echo e($lang->code); ?>" style="text-decoration: none; color: inherit;">
                                    <span class="fi fi-<?php echo e($lang->site_code); ?>"></span>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                    <div class="btn-box">
                        <a href="index-2.html" class="theme-btn btn-one"><?php echo e(__("site.Appointment")); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--sticky Header-->
    <div class="sticky-header">
        <div class="auto-container">
            <div class="outer-box">
                <div class="logo-box">
                    <figure class="logo"><a href="<?php echo e(route("client.home")); ?>"><img src="<?php echo e($infos->getImage($infos->logo)); ?>" alt=""></a></figure>
                </div>
                <div class="menu-area clearfix">
                    <nav class="main-menu clearfix">
                        <!--Keep This Empty / Menu will come through Javascript-->
                    </nav>
                </div>
                <div class="nav-right">

                    <div class="btn-box">
                        <a href="<?php echo e(route("client.home")); ?>" class="theme-btn btn-one"><?php echo e(__("site.Appointment")); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- main-header end -->

<!-- Mobile Menu  -->
<div class="mobile-menu">
    <div class="menu-backdrop"></div>
    <div class="close-btn"><i class="fas fa-times"></i></div>

    <nav class="menu-box">
        <div class="nav-logo"><a href="<?php echo e(route("client.home")); ?>"><img src="<?php echo e($infos->getImage($infos->logo)); ?>" alt="" title=""></a></div>
        <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
        <div class="contact-info">
            <h4>Contact Info</h4>
            <ul>
                <li><a href="tel:<?php echo e(preg_replace('/[^0-9]/', '', $phone)); ?>"><?php echo e($phone); ?></a></li>
                <li><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></li>
            </ul>
        </div>
        <div class="social-links">
            <ul class="clearfix">
                <?php if(!empty($infos->twitter)): ?>
                    <li><a href="<?php echo e($infos->twitter); ?>" target="_blank"><span class="fab fa-twitter"></span></a></li>
                <?php endif; ?>

                <?php if(!empty($infos->facebook)): ?>
                    <li><a href="<?php echo e($infos->facebook); ?>" target="_blank"><span class="fab fa-facebook-square"></span></a></li>
                <?php endif; ?>

                <?php if(!empty($infos->pinterest)): ?>
                    <li><a href="<?php echo e($infos->pinterest); ?>" target="_blank"><span class="fab fa-pinterest-p"></span></a></li>
                <?php endif; ?>

                <?php if(!empty($infos->instagram)): ?>
                    <li><a href="<?php echo e($infos->instagram); ?>" target="_blank"><span class="fab fa-instagram"></span></a></li>
                <?php endif; ?>

                <?php if(!empty($infos->youtube)): ?>
                    <li><a href="<?php echo e($infos->youtube); ?>" target="_blank"><span class="fab fa-youtube"></span></a></li>
                <?php endif; ?>
            </ul>

        </div>
    </nav>
</div><!-- End Mobile Menu -->
<?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/components/client-header-component.blade.php ENDPATH**/ ?>