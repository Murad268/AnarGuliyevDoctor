<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._breadcrumb', ['first_crumb' => ['title'=>__('breadcrumb.sitePolicy'), 'link' => route('client.sitePolicy')], 'second_crumb' => ['title' => __('breadcrumb.privacyPolicy')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials._title', ['code' => __('breadcrumb.privacyPolicy'), "is_details" => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Start blog single area-->
    <section id="blog-area" class="blog-area blog-single-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                    <div class="blog-post">
                        <div class="single-blog-post">
                            <div class="text-holder">
                                <h3 class="blog-title">Privacy Policy</h3>
                                <ul class="meta-info">
                                    <li><span>Effective Date</span></li>
                                    <li><span><?php echo e(\Carbon\Carbon::parse($policy->privacyPolicy->date)->locale(app()->getLocale())->isoFormat('LL')); ?></span></li>
                                </ul>
                            </div>
                        </div>
                        <!--Start bottom content box-->
                        <div class="bottom-content-box">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo $policy->privacyPolicy->text; ?>

                                </div>
                            </div>
                        </div>
                        <!--End bottom content box-->

                    </div>
                </div>


            </div>
        </div>
    </section>
    <!--End blog single area-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/pages/privacyPolicy.blade.php ENDPATH**/ ?>