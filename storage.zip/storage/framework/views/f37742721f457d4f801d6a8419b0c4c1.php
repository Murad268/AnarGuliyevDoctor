<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._breadcrumb', ['first_crumb' => ['title'=>__('breadcrumb.services'), 'link' => route('client.services')], 'second_crumb' => ['title' => $service->title]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials._title', ['code' => $service->title, "is_details" => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Start service single area-->
    <section id="service-single-area" class="smartphone-repair-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 pull-right">
                    <div class="service-single-content">
                        <!--Start top content -->
                        <div class="row top-content">
                            <div class="col-md-5 col-sm-12 col-xs-12">
                                <div class="img-holder wow zoomInStable animated">
                                    <img src="<?php echo e($service->getImage($service->image)); ?>" alt="<?php echo e($service->title); ?>">
                                </div>
                            </div>
                            <div class="col-md-7 col-sm-12 col-xs-12">
                                <div class="text-holder">
                                    <div class="title">
                                        <h2><?php echo e($service->title); ?></h2>
                                    </div>
                                    <div class="text">
                                        <span><?php echo e($service->colored_subtitle); ?></span>
                                        <?php echo $service->text; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End top content -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="border"></div>
                            </div>
                        </div>

                        <!--Start Consultation form-->
                        <div class="appoinment-form">
                            <div class="title">
                                <h2><?php echo e(__('site.make_a_abonoment')); ?></h2>
                            </div>
                            <form id="appoinment-form" method="POST" action="<?php echo e(route('contact.service')); ?>">
                                <?php echo csrf_field(); ?> <!-- Important for Laravel POST forms -->
                                <input type="hidden" name="service_title" value="<?php echo e($service->title); ?>">
                                <div class="row">
                                    <div class="col-md-6">
                                        <input type="text" name="form_name" value="" placeholder="<?php echo e(__('form.your_name')); ?>*" required="">
                                        <input type="email" name="form_email" value="" placeholder="<?php echo e(__('form.your_email')); ?>*" required="">
                                        <input type="text" name="form_phone" value="" placeholder="<?php echo e(__('form.your_email')); ?>*" required="">
                                    </div>
                                    <div class="col-md-6">
                                        <textarea name="form_message" placeholder="<?php echo e(__('form.your_message')); ?>.." required=""></textarea>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" name="address" value="" placeholder="<?php echo e(__('form.your_address')); ?>*" required="">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <button class="thm-btn bg-1" type="submit"><?php echo e(__('site.submit_now')); ?></button>
                                    </div>
                                </div>
                            </form>

                        </div>
                        <!--End Consultation form-->
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-7 col-xs-12 pull-left">
                    <div class="service-single-sidebar">
                        <!--Start single sidebar-->
                        <div class="single-sidebar">
                            <ul class="service-lists">
                                <?php if($allServicesCount > 10): ?>
                                    <li class="allservice">
                                        <a href="<?php echo e(route('client.services')); ?>">View All Services<i class="fa fa-cog" aria-hidden="true"></i></a>
                                    </li>
                                <?php endif; ?>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php echo e($service->slug == $slug ? 'active': ''); ?>">
                                        <a href="<?php echo e(route('client.service', $service->slug)); ?>"><?php echo e($service->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!--End single sidebar-->

                    </div>
                </div>

            </div>
        </div>
    </section>
    <div id="loading-overlay" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255, 255, 255, 0.8); z-index: 9999; text-align: center;">
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
            <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>

    <!--End service single area-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function () {
            $('#appoinment-form').on('submit', function (e) {
                e.preventDefault(); // Prevent default form submission

                // Show the loading overlay, disable the submit button, and disable page scrolling
                $('#loading-overlay').show();
                $('button[type="submit"]').prop('disabled', true);
                $('body').css('overflow', 'hidden'); // Disable scrolling

                let formData = $(this).serialize(); // Serialize form data

                $.ajax({
                    url: "<?php echo e(route('contact.service')); ?>", // The form action URL
                    type: "POST", // HTTP method
                    data: formData,
                    success: function (response) {
                        $('#loading-overlay').hide(); // Hide the loading overlay
                        $('button[type="submit"]').prop('disabled', false); // Re-enable the button
                        $('body').css('overflow', ''); // Restore scrolling

                        if (response.success) {
                            // SweetAlert success
                            Swal.fire({
                                title: 'Success!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });

                            // Optionally clear the form
                            $('#appoinment-form')[0].reset();
                        }
                    },
                    error: function (xhr) {
                        $('#loading-overlay').hide(); // Hide the loading overlay
                        $('button[type="submit"]').prop('disabled', false); // Re-enable the button
                        $('body').css('overflow', ''); // Restore scrolling

                        let errors = xhr.responseJSON.errors;

                        // SweetAlert error
                        Swal.fire({
                            title: 'Error!',
                            text: 'Please correct the errors and try again.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });

                        // Optionally display the validation errors in console
                        console.error(errors);
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/pages/service.blade.php ENDPATH**/ ?>