<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._breadcrumb', ['first_crumb' => ['title'=>__('breadcrumb.services'), 'link' => route('client.services')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials._title', ['code' => 'services'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Start services page area-->
    <section class="services-page-area">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Start single item-->
                    <div class="col-md-4">
                        <div class="single-item">
                            <div class="img-holder">
                                <img src="<?php echo e($service->getImage($service->image)); ?>" alt="<?php echo e($service->title); ?>">
                                <a href="<?php echo e(route('client.service', $service->slug)); ?>" class="iocn-holder">
                                    <span class="flaticon-arrows-1"></span>
                                </a>
                            </div>
                            <div class="text-holder">
                                <h3><?php echo e($service->title); ?></h3>
                                <p><?php echo Str::limit(strip_tags($service->text), 70, '...'); ?></p>
                                <a href="<?php echo e(route('client.service', $service->slug)); ?>"><?php echo e(__('site.read_more')); ?><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <!--End single item-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php if($services->count()>9): ?>
                <!--Start post pagination-->
                <div class="row">
                    <div class="col-md-12">
                        <ul class="post-pagination text-center">
                            
                            <?php if($services->onFirstPage()): ?>
                                <li class="disabled"><span><i class="fa fa-caret-left" aria-hidden="true"></i></span></li>
                            <?php else: ?>
                                <li><a href="<?php echo e($services->previousPageUrl()); ?>"><i class="fa fa-caret-left" aria-hidden="true"></i></a></li>
                            <?php endif; ?>

                            
                            <?php for($i = 1; $i <= $services->lastPage(); $i++): ?>
                                <li class="<?php echo e(($services->currentPage() == $i) ? 'active' : ''); ?>">
                                    <a href="<?php echo e($services->url($i)); ?>"><?php echo e($i); ?></a>
                                </li>
                            <?php endfor; ?>

                            
                            <?php if($services->hasMorePages()): ?>
                                <li><a href="<?php echo e($services->nextPageUrl()); ?>"><i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                            <?php else: ?>
                                <li class="disabled"><span><i class="fa fa-caret-right" aria-hidden="true"></i></span></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <!--End post pagination-->
            <?php endif; ?>

        </div>
    </section>
    <!--End services page area-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/pages/services.blade.php ENDPATH**/ ?>