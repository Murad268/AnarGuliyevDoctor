<figure class="image image-style-align-center">
    <img src="https://wallpapercave.com/wp/OndoxGj.jpg" alt="ExoPlanet">
    <figcaption>ExoPlanet</figcaption>
</figure>
<?php /**PATH C:\Users\TechEvo Computers\Desktop\doctor\resources\views/ckeditor/image.blade.php ENDPATH**/ ?>