<?php $__env->startSection('content'); ?>
   <?php echo $__env->make('partials._breadcrumb', ['first_crumb' => ['title'=>__('breadcrumb.about'), 'link' => route('client.about')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('partials._title', ['code' => 'about'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Start about us area-->
    <section id="about" class="about-us-area">
        <?php if (isset($component)) { $__componentOriginalbf57d73fb5d415a75248397fb052c338 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbf57d73fb5d415a75248397fb052c338 = $attributes; } ?>
<?php $component = App\View\Components\AboutComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('about-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AboutComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbf57d73fb5d415a75248397fb052c338)): ?>
<?php $attributes = $__attributesOriginalbf57d73fb5d415a75248397fb052c338; ?>
<?php unset($__attributesOriginalbf57d73fb5d415a75248397fb052c338); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbf57d73fb5d415a75248397fb052c338)): ?>
<?php $component = $__componentOriginalbf57d73fb5d415a75248397fb052c338; ?>
<?php unset($__componentOriginalbf57d73fb5d415a75248397fb052c338); ?>
<?php endif; ?>
    </section>
    <!--End about us area-->

    <?php if (isset($component)) { $__componentOriginal69b0059ab78618977137eb53c6af577d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69b0059ab78618977137eb53c6af577d = $attributes; } ?>
<?php $component = App\View\Components\WhyChooseUsComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('why-choose-us-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\WhyChooseUsComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69b0059ab78618977137eb53c6af577d)): ?>
<?php $attributes = $__attributesOriginal69b0059ab78618977137eb53c6af577d; ?>
<?php unset($__attributesOriginal69b0059ab78618977137eb53c6af577d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69b0059ab78618977137eb53c6af577d)): ?>
<?php $component = $__componentOriginal69b0059ab78618977137eb53c6af577d; ?>
<?php unset($__componentOriginal69b0059ab78618977137eb53c6af577d); ?>
<?php endif; ?>


    <!--Start team area-->
    <section class="team-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="sec-title center text-center">
                        <h1><span><?php echo e(__('site.meet_our_team')); ?></span></h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Start single team member-->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single-team-member">
                        <div class="img-holder">
                            <img src="<?php echo e($member->image ? $member->getImage($member->image) :  asset('assets/default-user.png')); ?>" alt="Awesome Image">
                            <div class="overlay-one">
                                
                            </div>
                        </div>
                        <div class="text-holder">
                            <h3><?php echo e($member->full_name); ?></h3>
                            <span><?php echo e($member->position); ?></span>
                        </div>
                    </div>
                    </div>
                    <!--End single team member-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--End team area-->


    <?php if (isset($component)) { $__componentOriginalb2629a48c04228b0b7b2d1da6709ceba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2629a48c04228b0b7b2d1da6709ceba = $attributes; } ?>
<?php $component = App\View\Components\PartnersComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partners-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PartnersComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2629a48c04228b0b7b2d1da6709ceba)): ?>
<?php $attributes = $__attributesOriginalb2629a48c04228b0b7b2d1da6709ceba; ?>
<?php unset($__attributesOriginalb2629a48c04228b0b7b2d1da6709ceba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2629a48c04228b0b7b2d1da6709ceba)): ?>
<?php $component = $__componentOriginalb2629a48c04228b0b7b2d1da6709ceba; ?>
<?php unset($__componentOriginalb2629a48c04228b0b7b2d1da6709ceba); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/pages/about.blade.php ENDPATH**/ ?>