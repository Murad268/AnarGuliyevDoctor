<!--Start breadcrumb area-->
<section class="breadcrumb-area">
    <div class="container text-center">

        <?php if(isset($second_crumb)): ?>
            <h1><?php echo e($second_crumb['title']); ?></h1
        <?php else: ?>
            <h1><?php echo e($first_crumb['title']); ?></h1>
        <?php endif; ?>
    </div>
</section>
<!--End breadcrumb area-->

<!--Start breadcrumb bottom area-->
<section class="breadcrumb-botton-area">
    <div class="container">
        <div class="left">
            <ul>
                <li><a href="<?php echo e(route('client.home')); ?>"><?php echo e(__('breadcrumb.home')); ?></a></li>
                <li><i class="fa fa-caret-right" aria-hidden="true"></i></li>
                <li class="<?php echo e(isset($second_crumb)?'':'active'); ?>"><a href="<?php echo e($first_crumb['link']); ?>"><?php echo e($first_crumb['title']); ?></a></li>
                <?php if(isset($second_crumb)): ?>
                    <li><i class="fa fa-caret-right" aria-hidden="true"></i></li>
                    <li class="<?php echo e($second_crumb?'active':''); ?>"><?php echo e($second_crumb['title']); ?></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</section>
<!--End breadcrumb bottom area-->
<?php /**PATH C:\Users\TechEvo Computers\Desktop\leader-app\resources\views/partials/_breadcrumb.blade.php ENDPATH**/ ?>